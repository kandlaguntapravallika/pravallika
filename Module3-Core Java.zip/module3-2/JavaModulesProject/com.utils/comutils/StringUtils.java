package comutils;

public class StringUtils {
    public static String upperCase(String input) {
        return input.toUpperCase();
    }
}
