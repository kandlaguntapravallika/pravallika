public class Hello {
    public void greet() {
        System.out.println("Hello Bytecode!");
    }
}
