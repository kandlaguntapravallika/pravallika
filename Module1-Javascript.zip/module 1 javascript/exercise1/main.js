console.log("Welcome to the Community Portal");

window.onload = () => {
  alert("Page fully loaded!");
};
